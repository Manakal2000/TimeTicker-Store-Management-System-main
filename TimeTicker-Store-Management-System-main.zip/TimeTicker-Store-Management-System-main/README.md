# TimeTicker-Store-Management-System

This is Store Management System for Watch Repair Store.
In this application we provide functionality to  create,update,delete,view details about invoices as well as supplier details,product details.
staff can also view monthly income and expences report.

### Tech Stack
* Java (Maven repository)
* SQL

